﻿██╗  ██╗ ██████╗ ██╗  ██╗██╗  ██╗██╗   ██╗██████╗     ██████╗  █████╗    ██╗   █████╗ 
██║  ██║██╔═══██╗╚██╗██╔╝██║  ██║██║   ██║██╔══██╗    ██╔══██╗██╔══██╗  ███║  ██╔══██╗
███████║██║   ██║ ╚███╔╝ ███████║██║   ██║██║  ██║    ██████╔╝╚██████║  ╚██║  ╚██████║
██╔══██║██║   ██║ ██╔██╗ ██╔══██║██║   ██║██║  ██║    ██╔═══╝  ╚═══██║   ██║   ╚═══██║
██║  ██║╚██████╔╝██╔╝ ██╗██║  ██║╚██████╔╝██████╔╝    ██║      █████╔╝██╗██║██╗█████╔╝
╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝     ╚═╝      ╚════╝ ╚═╝╚═╝╚═╝╚════╝


Installation Guide:
1: Extract ALL the files from the .7z without modifying the structure. You can of course omit this README, but nothing else.
2: Go to steamapps\common\Payday 2 and put the contents there.
3: Launch Payday 2.
3b: If it crashes/doesn't launch download the VC redist file below.

Make sure you have joined HoxHud Public Group or HoxHud will not be active while playing.

http://www.microsoft.com/en-us/download/details.aspx?id=40784
32 bit Windows users download and install the x86 version in the link above
64 bit Windows users download and install both x86 and x64.

A large portion of the HUD can be modified in-game by going to the options menu.
More esoteric options are in the HoxHudTweakData.

If you need help configuring it try asking people in the group chat.

Bugs can be posted in the discussion forum for them in the HoxHud group, and if you
have any other questions try asking in the group chat.

If you want to disable the "HoxHud Initialised" Voice line that was kindly contributed by Old Hoxton (Pete Gold)
Simply delete the MP3 from the HoxHud folder.

If you want to uninstall HoxHud, delete HoxHud.DLL and IPHLPAPI.dll, it is NOT NECESSARY to delete the HoxHud folder.

Disclaimer:

HoxHUD is an incomplete mod for Payday 2. 
We do not guarantee that HoxHUD is compatible with your computer, any other mods, or clients you are using. 
Wine-Bottled Payday 2 is not supported actively, hacked clients are not supported and any mods that you have that run in conjunction with HoxHUD can potentially cause crashing.

To better your HoxHUD experience, read the forums and atttempt to keep redundant modding to the ABSOLUTE minimum.
If you have any questions, remember there's a search bar for the forums that will probably get you answers, 
whereas reposting garbage that we've already answered will result in some moderators verbally berating you in a manner roughly equivalent to being beaten with a hard-backed, unabridged copy of Homer's "The Odessey"

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.